package com.grocery.booking.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryBookingSystemApplication.class, args);
	}

}
