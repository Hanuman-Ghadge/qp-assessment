package com.grocery.booking.system.controllers;
import com.grocery.booking.system.entity.Grocery;
import com.grocery.booking.system.repository.GroceryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/items")
public class UserController {
    @Autowired
    private GroceryRepo groceryItemRepository;

    @GetMapping
    public List<Grocery> getAvailableItems() {
        return groceryItemRepository.findAll();
    }

    @PostMapping("/orders")
    public ResponseEntity<String> bookItems(@RequestBody Order order) {
        return ResponseEntity.ok("Order placed successfully");
    }
}
