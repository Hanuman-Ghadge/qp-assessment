package com.grocery.booking.system.repository;

import com.grocery.booking.system.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;


public interface OrderRepository extends JpaRepository<Order, Long> {}
