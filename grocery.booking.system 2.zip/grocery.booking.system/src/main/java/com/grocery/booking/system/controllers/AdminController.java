package com.grocery.booking.system.controllers;

import com.grocery.booking.system.entity.Grocery;
import com.grocery.booking.system.repository.GroceryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;

import java.util.Map;

public class AdminController {

    @Autowired
    private GroceryRepo groceryRep;

    @PostMapping
    public ResponseEntity<Grocery> addItem(@RequestBody Grocery itm) {
        return ResponseEntity.status(HttpStatus.CREATED).body(groceryRep.save(itm));
    }

    @GetMapping
    public List<Grocery> getItems() {
        return groceryRep.findAll();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> removeItem(@PathVariable Long id) {
        groceryRep.deleteById(id);
        return ResponseEntity.ok("Product removed");
    }

    @PutMapping("/{id}")
    public ResponseEntity<Grocery> updateItem(@PathVariable Long id, @RequestBody Grocery product) {
        product.setId(id);
        return ResponseEntity.ok(groceryRep.save(item));
    }

    @PatchMapping("/{id}/inventory")
    public ResponseEntity<Grocery> updateInventory(@PathVariable Long id, @RequestBody Map<String, Integer> produtcToPatch) {
        Grocery item = groceryRep.findById(id).orElseThrow();
        item.setInventory(produtcToPatch.get("inventory"));
        return ResponseEntity.ok(groceryRep.save(item));
    }

}
