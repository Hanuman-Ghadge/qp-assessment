package com.grocery.booking.system.repository;

import com.grocery.booking.system.entity.Grocery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroceryRepo extends JpaRepository<Grocery, Long> {

}
